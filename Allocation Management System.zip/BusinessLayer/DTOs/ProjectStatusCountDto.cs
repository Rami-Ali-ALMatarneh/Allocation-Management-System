﻿namespace BusinessLayer.DTOs
{
    public class ProjectStatusCountDto
    {
        public string Status { get; set; }
        public int Count { get; set; }
    }
}
