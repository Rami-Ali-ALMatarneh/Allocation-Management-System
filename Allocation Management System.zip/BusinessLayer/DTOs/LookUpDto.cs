﻿namespace BusinessLayer.DTOs
{
    public class LookUpDto
    {

        public int LookUpId { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
        public int LookupCategoryId { get; set; }
    }
}
