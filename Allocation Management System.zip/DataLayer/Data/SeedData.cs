﻿using DataLayer.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace DataLayer.Data
{
    public static class SeedData
    {
        public static async Task InitializeUser(UserManager<User> userManager, RoleManager<IdentityRole<int>> roleManager)
        {
            if (await userManager.Users.AnyAsync())
                return;
            var roles = new List<IdentityRole<int>>()
                {
                new IdentityRole<int>{Name="Project Delivery Manager"},
                new IdentityRole<int>{Name="HR Officer"},
                };
            foreach (var role in roles)
            {
                await roleManager.CreateAsync(role);
            }
            var Admin = new User()
            {
                Fname = "Saeed",
                Lname = "Abd Al-Ati",
                UserName = "admin_tps2024",
                Email = "admintps2024@techprocess.net",
                EmailConfirmed = true,
                PhoneNumber = "0777777777",
                Gender = "male"

            };
            await userManager.CreateAsync(Admin, "Pa$$w0rd");
            await userManager.AddToRoleAsync(Admin, "Project Delivery Manager");
            var HR = new User()
            {
                Fname = "hr",
                Lname = "tps",
                UserName = "hr_tps2024",
                Email = "hrtps2024@techprocess.net",
                PhoneNumber = "0777777777",
                Gender = "female"
            };
            await userManager.CreateAsync(HR, "Pa$$w0rd");
            await userManager.AddToRoleAsync(HR, "HR Officer");
        }

    }
}
