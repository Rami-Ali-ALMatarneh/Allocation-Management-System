﻿namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace PresentationLayer.wwwroot.RDLCReport.RDLCAllocationReport
    {
    }

namespace WinFormsApp2
    {
    }

namespace WinFormsApp2
    {
    }

namespace WinFormsApp2
    {
    }

namespace WinFormsApp2
    {
    }

public partial class AllocationDataSet
    {
    partial class AllocationDataSetDataTable
        {
        }
    }
