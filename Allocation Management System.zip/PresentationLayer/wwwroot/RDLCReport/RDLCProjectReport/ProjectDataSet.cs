﻿namespace PresentationLayer.wwwroot.RDLCReport.RDLCProjectReport
    {
    }

namespace WinFormsApp1
    {
    }

namespace WinFormsApp1
    {
    }

namespace WinFormsApp1
    {
    }

namespace WinFormsApp1
    {
    }

namespace WinFormsApp1
    {
    }

namespace WinFormsApp1
    {
    }

public partial class ProjectDataSet {
}
